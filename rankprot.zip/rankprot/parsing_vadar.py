#! /user/bin/env python3
import sys
import math

#taking input from a file
file= open(sys.argv[1], mode='r', encoding='iso-8859-1')
atom = float(sys.argv[2])
sample = []
flag = 0

sample = file.read().split('|')
sample = [x.strip(' \t\n\r') for x in sample]
#print(sample)



#Percentage of residues forming Hydrogen bond
hy_bond = sample.index('# res with hbonds') + 1
x = sample[hy_bond].split('(')
x = x[1].split('%')
x = x[0].strip(' ')
final_output = x + ';'

#Fraction Polar ASA
polar = sample.index('Fraction polar ASA')+1
x = sample[polar].strip(' ')
final_output = final_output + str(float(x)*100) + ';'

#Fraction non Polar ASA
non_polar = sample.index('Fraction nonpolar ASA')+1
x = sample[non_polar].strip(' ')
final_output = final_output + str(float(x)*100) + ';'


#Fraction charged ASA
polar = sample.index('Fraction charged ASA')+1
x = sample[polar].strip(' ')
final_output = final_output + str(float(x)*100) + ';'


#Packing volume
vol = sample.index('Total volume (packing)')+1
x = sample[vol].split('A')
x = x[0].strip(' ')
final_output = final_output + str(float(x)/atom*100) 

print(final_output)
