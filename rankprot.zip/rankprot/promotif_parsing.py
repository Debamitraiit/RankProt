#! /user/bin/env python3
import sys
import math

gamma = float(sys.argv[1])
gamma_inverse = float(sys.argv[2])
beta = float(sys.argv[3])
residue = float(sys.argv[4])

print(str(gamma/residue*100) + ';' + str(gamma_inverse/residue*100) + ';' + str(beta/residue*100) )
