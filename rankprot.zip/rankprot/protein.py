#! /user/bin/env python3
import sys
import math

#taking input from a file
file= open(sys.argv[1])
sample = []
flag = 0
atom_count = 0
residue_count = []
# Read lines from the PDB file and put it in the list 
for lines in file.readlines():
	if(lines[0:4].replace(" ",'') == 'ATOM'):
		t = []
		header = []
		atom_count = atom_count + 1
		a = lines[0:6].replace(" ","")
		if(flag == 0):
			header.append('ATOM')
		t.append(a)
		a = lines[6:11].replace(" ","")
		if(flag == 0):
			header.append('SERIAL_NUMBER')
		t.append(a)
		a = lines[12:16].replace(" ","")
		if(flag == 0):
			header.append('NAME')
		t.append(a)
		a = lines[16].replace(" ","")
		if(flag == 0):
			header.append('ALT_LOCATION')
		t.append(a)
		a = lines[17:20].replace(" ","")
		if(flag == 0):
			header.append('RESIDUE')
		t.append(a)
		a = lines[21].replace(" ","")
		if(flag == 0):
			header.append('CHAIN')
		residue_temp = a
		t.append(a)
		a = lines[22:26].replace(" ","")
		if(flag == 0):
			header.append('RESIDUE_SEQUENCE_NO')
		residue_temp = residue_temp + a
		residue_count.append(residue_temp)
		t.append(a)
		a = lines[26].replace(" ","")
		if(flag == 0):
			header.append('INSERTION_RESIDUE_CODE')
		t.append(a)
		a = lines[30:38].replace(" ","")
		if(flag == 0):
			header.append('X_COORDI')
		t.append(a)
		a = lines[38:46].replace(" ","")
		if(flag == 0):
			header.append('Y_COORDI')
		t.append(a)	
		a = lines[46:54].replace(" ","")
		if(flag == 0):
			header.append('Z_COORDI')
		t.append(a)
		a = lines[54:60].replace(" ","")
		if(flag == 0):
			header.append('OCCUPANCY')
		t.append(a)
		a = lines[60:66].replace(" ","")
		if(flag == 0):
			header.append('TEMP_FACTOR')
		t.append(a)
		a = lines[66:76].replace(" ","")
		if(flag == 0):
			header.append('SEG_IDENTI')
		t.append(a)
		a = lines[76:78].replace(" ","")
		if(flag == 0):
			header.append('ELE_SYMBOL')
		t.append(a)
		a = lines[78:80].replace(" ","")
		if(flag == 0):
			header.append('CHARGE')
		t.append(a)
		if(flag == 0):
			sample.append(header)
			flag = 1
		sample.append(t)
		



	

	

#sorting order printing the output 
def output_in_sorted_order(output):
	output.sort(key=lambda x:int(x[3]))								
	output.sort(key=lambda x:int(x[0]))
	print('\nPOSITION\tRESIDUE\tCHAIN\tPOSITION\tRESIDUE\tCHAIN\tDISTANCE\n')
	q = 1
	for i in range(0,len(output)):
		for j in range(0,len(output[i])):
			if(i == 0):
				print(str(output[i][j])+'\t',end='')
			if(i > 0 and (output[i][3] != output[i-1][3] or output[i][0] != output[i-1][0])):
				print(str(output[i][j])+'\t',end='')
		if(i > 0 and (output[i][3] != output[i-1][3] or output[i][0] != output[i-1][0])):
			q = q+1
			print(q)
		if(i==0):
			print(q)
def output_interaction_in_sorted_order(output):
	output.sort(key=lambda x:int(x[3]))								
	output.sort(key=lambda x:int(x[0]))
	q = 1
	for i in range(0,len(output)):
		if(i > 0 and (output[i][3] != output[i-1][3] or output[i][0] != output[i-1][0])):
			q = q+1
	return q
			
def output_in_sorted_order_Hydrogen(output):
	output.sort(key=lambda x:int(x[4]))								
	output.sort(key=lambda x:int(x[0]))
	print('\nPOSITION\tRESIDUE\tCHAIN\tAtom\tPOSITION\tRESIDUE\tCHAIN\tAtom\tDISTANCE Donor-Acceptor\n')
	q = 1
	for i in range(0,len(output)):
		for j in range(0,len(output[i])):
			if(i == 0):
				print(str(output[i][j])+'\t',end='')
			if(i > 0 and ((output[i][4] != output[i-1][4] or output[i][0] != output[i-1][0]) or (output[i][7] != output[i-1][7] or output[i][3] != output[i-1][3]) )):
				print(str(output[i][j])+'\t',end='')
		if(i > 0 and ((output[i][4] != output[i-1][4] or output[i][0] != output[i-1][0]) or (output[i][7] != output[i-1][7] or output[i][3] != output[i-1][3]) )):
			q = q+1
			print(q)
		if(i==0):
			print(q)
def output_interaction_in_sorted_order_Hydrogen(output):
	output.sort(key=lambda x:int(x[4]))								
	output.sort(key=lambda x:int(x[0]))
	q = 1
	for i in range(0,len(output)):
		if(i > 0 and ((output[i][4] != output[i-1][4] or output[i][0] != output[i-1][0]) or (output[i][7] != output[i-1][7] or output[i][3] != output[i-1][3]) )):
			q = q+1
	return q
#append output to the list
def append_result_in_output(output,t,s,distance):
	out =[]
	out.append(sample[t][residue_sequence_no])
	out.append(sample[t][residue])
	out.append(sample[t][chain])
	out.append(sample[s][residue_sequence_no])
	out.append(sample[s][residue])
	out.append(sample[s][chain])
	if(distance >= 0.0):
		out.append(math.sqrt(distance))
	output.append(out)
	return output
	
def append_result_in_output_Hydrogen(output,t,s,distance):
	out =[]
	out.append(sample[t][residue_sequence_no])
	out.append(sample[t][residue])
	out.append(sample[t][chain])
	out.append(sample[t][name])	
	out.append(sample[s][residue_sequence_no])
	out.append(sample[s][residue])
	out.append(sample[s][chain])
	out.append(sample[s][name])
	if(distance >= 0.0):
		out.append(math.sqrt(distance))
	output.append(out)
	return output
	
def distance_calculation(t,s):
	distance = (float(sample[t][x_coordi]) - float(sample[s][x_coordi]))* (float(sample[t][x_coordi]) - float(sample[s][x_coordi])) + (float(sample[t][y_coordi]) - float(sample[s][y_coordi])) * (float(sample[t][y_coordi]) - float(sample[s][y_coordi])) + (float(sample[t][z_coordi]) - float(sample[s][z_coordi])) * (float(sample[t][z_coordi]) - float(sample[s][z_coordi]))	
	return distance

def append_function(list_amino_acid,i):
	if(sample[i][name] == 'O'):
			list_amino_acid[1].append(i)
	if(sample[i][name] == 'N'):
			list_amino_acid[0].append(i)
	return list_amino_acid
	
def append_in_both_list(list_amino_acid,i):
	list_amino_acid[0].append(i)
	list_amino_acid[1].append(i)
	return list_amino_acid	
	
def print_output_hydrogen_chain(result):
	output =[]	
	for i in range(len(result)):
		for j in range(0,1):
			for k in range(len(result[i][j])):
				t= result[i][j][k]
				for l in range(len(result)):
					for m in range(1,2):
						for n in range(len(result[l][m])):
							if(i==l):
								continue
							if(j==m):
								continue
							else:
								s = result[l][m][n]
							distance = distance_calculation(t,s)
							if(distance <= 12.25 and distance >=0.0):
								append_result_in_output_Hydrogen(output,t,s,distance)
	output_in_sorted_order_Hydrogen(output)

def print_interaction_output_hydrogen_chain(result):
	output =[]	
	for i in range(len(result)):
		for j in range(0,1):
			for k in range(len(result[i][j])):
				t= result[i][j][k]
				for l in range(len(result)):
					for m in range(1,2):
						for n in range(len(result[l][m])):
							if(i==l):
								continue
							if(j==m):
								continue
							else:
								s = result[l][m][n]
							distance = distance_calculation(t,s)
							if(distance <= 12.25 and distance >=0.0):
								append_result_in_output_Hydrogen(output,t,s,distance)
	return output_interaction_in_sorted_order_Hydrogen(output)
	
#for calculating hydrophobic interaction
# printing the initial information
#print('\nFollowing atoms of amino acids have hydophobic interaction \nSerial NO.\tName of Amino Acid\tATOM Name\n1)\t\tALANINE\t\t\tCB\n2)\t\tVALINE\t\t\tCB,CG1,CG2\n3)\t\tLEUCINE\t\t\tCB,CG,CD1,CD2\n4)\t\tISOLUCINE\t\tCB,CG1,CG2,CD\n5)\t\tMETHIONINE\t\tCB,CG,CE\n6)\t\tPHENYLALANINE\t\tCB,CG,CD1,CD2,CE1,CE2,CZ\n7)\t\tTRYPTOPHAN\t\tCB,CG,CD1,CD2,CE2,CE3,CZ2,CZ3,CH2\n8)\t\tPROLINE\t\t\tCB,CG,CD\n9)\t\tTRYOSINE\t\tCB,CG,CD1,CD2,CE1,CE2,CZ\n')
# list of list to store the corresponding amino acid
result = []
ala = [[]]
val = [[],[],[]]
leu = [[],[],[],[]]
ile = [[],[],[],[]]
met = [[],[],[]]
phe = [[],[],[],[],[],[],[]]
trp = [[],[],[],[],[],[],[],[],[]]
pro = [[],[],[]]
tyr = [[],[],[],[],[],[],[]]
cys = []
# define some variables
residue = sample[0].index('RESIDUE')
x_coordi = sample[0].index('X_COORDI')
y_coordi = sample[0].index('Y_COORDI')
z_coordi = sample[0].index('Z_COORDI')
serial_number = sample[0].index('SERIAL_NUMBER')
name = sample[0].index('NAME')
chain = sample[0].index('CHAIN')
residue_sequence_no = sample[0].index('RESIDUE_SEQUENCE_NO')
#print('\nPOSITION\tRESIDUE\tCHAIN\tPOSITION\tRESIDUE\tCHAIN\n')
# read from file and store it in the above list 
for i in range(1,len(sample)):
	if (sample[i][residue] == 'ALA' and sample[i][name] == 'CB'):
		ala[0].append(i)
	if(sample[i][residue] == 'VAL'):
		if(sample[i][name] == 'CB'):
			val[0].append(i)
		if(sample[i][name] == 'CG1'):
			val[1].append(i)
		if(sample[i][name] == 'CG2'):
			val[2].append(i)
	if((sample[i][residue] == 'LEU' )):
		if(sample[i][name] == 'CB'):
			leu[0].append(i)
		if(sample[i][name] == 'CG'):
			leu[1].append(i)
		if(sample[i][name] == 'CD1'):
			leu[2].append(i)
		if(sample[i][name] == 'CD2'):
			leu[3].append(i)
	if((sample[i][residue] == 'ILE')):
		if( sample[i][name] == 'CB'):
			ile[0].append(i)
		if(sample[i][name] == 'CG1'):
			ile[1].append(i)
		if(sample[i][name] == 'CG2'):
			ile[2].append(i)
		if(sample[i][name] == 'CD1' or sample[i][name] == 'CD' ):
			ile[3].append(i)
	if((sample[i][residue] == 'MET')):
		if( sample[i][name] == 'CB'):
			met[0].append(i)
		if(sample[i][name] == 'CG'):
			met[1].append(i)
		if(sample[i][name] == 'CE' ):
			met[2].append(i)
	if(sample[i][residue] == 'PHE'):
		if( sample[i][name] == 'CG'):
			phe[0].append(i)
		if(sample[i][name] == 'CD1'):
			phe[1].append(i)
		if(sample[i][name] == 'CD2'):
			phe[2].append(i)
		if(sample[i][name] == 'CE1'):
			phe[3].append(i)
		if(sample[i][name] == 'CE2'):
			phe[4].append(i)
		if(sample[i][name] == 'CZ'):
			phe[5].append(i)
		if(sample[i][name] == 'CB'):
			phe[6].append(i)
	if((sample[i][residue] == 'TRP')):
		if( sample[i][name] == 'CG'):
			trp[0].append(i)
		if(sample[i][name] == 'CD1'):
			trp[1].append(i)
		if(sample[i][name] == 'CD2'):
			trp[2].append(i)
		if(sample[i][name] == 'CE2'):
			trp[3].append(i)
		if(sample[i][name] == 'CE3'):
			trp[4].append(i)
		if(sample[i][name] == 'CZ2'):
			trp[5].append(i)
		if(sample[i][name] == 'CZ3'):
			trp[6].append(i)
		if(sample[i][name] == 'CH2'):
			trp[7].append(i)
		if(sample[i][name] == 'CB'):
			trp[8].append(i)	
	if((sample[i][residue] == 'PRO')):
		if(sample[i][name] == 'CB'):
			pro[0].append(i)
		if(sample[i][name] == 'CG'):
			pro[1].append(i)
		if(sample[i][name] == 'CD'):
			pro[2].append(i)
	if(sample[i][residue] == 'TYR'):
		if( sample[i][name] == 'CG'):
			tyr[0].append(i)
		if(sample[i][name] == 'CD1'):
			tyr[1].append(i)
		if(sample[i][name] == 'CD2'):
			tyr[2].append(i)
		if(sample[i][name] == 'CE1'):
			tyr[3].append(i)
		if(sample[i][name] == 'CE2'):
			tyr[4].append(i)
		if(sample[i][name] == 'CZ'):
			tyr[5].append(i)
		if(sample[i][name] == 'CB'):
			tyr[6].append(i)
	if(sample[i][residue] == 'CYS'):
		if(sample[i][name] == 'SG'):
			cys.append(i)

result = [ala,val,leu,ile,met,phe,trp,pro,tyr]


# calculation of data 
output = []
out = []
for i in range(0,len(result)):
	for j in (range(0,len(result[i]))):
		for k in (range(0,len(result[i][j]))):
			t = result[i][j][k];
			for l in range(0,len(result)):
				for m in range(0,len(result[l])):
					for n in range(0, len(result[l][m])):
						s = result[l][m][n]
						if(i==l and k==n):
							continue
						elif(j > m and i==l):
							continue
						elif(i==l and j== m and k >= n):
							continue
						elif(i > l):
							continue
						else:
							if((i !=l or j != m or k != n )):
								s = result[l][m][n]
								distance = distance_calculation(t,s)	
								# #######################
								# distance error of 0.06
								# ######################
								if (distance <= 25.06 and t < s):
									append_result_in_output(output,t,s,-999.00)
								elif(distance <=25.06 and t >= s):
									append_result_in_output(output,s,t,-999.00)
# output the result 
#output_in_sorted_order(output)	
interaction_number = 	output_interaction_in_sorted_order(output)	

#print("Hydrophobic Interaction:  " + str(interaction_number/(len(sample)-1)*100)+" %")
final_ouput=""
final_output = str(interaction_number/(len(sample)-1)*100)+';'


#for calculating disulphide bridge
#print('\n\n\n\n\n\nFollowing atoms of amino acids make DISULPHIDE BRIDGES \nSerial NO.\tName of Amino Acid\tATOM Name\n1)\t\tCYSTEINE\t\t\tSG\n')
result = []
#print('\nPOSITION\tRESIDUE\tCHAIN\tPOSITION\tRESIDUE\tCHAIN\tDISTANCE\n')
result = cys
q = 0		
for i in range(0,len(result)):
	for j in range(i+1,len(result)):
		distance = distance_calculation(result[i],result[j])
		if (distance <= 4.84):
			q = q + 1
	else :
		continue 

interaction_number = q

#print("Disulphide Bridge Interaction:  " + str(interaction_number/(len(sample)-1)*100)+" %")
final_output = final_output+str(interaction_number/(len(sample)-1)*100)+';'

#hydrogen Bond
#main-main 
# [[acceptor][donor]]
#print("\nMain Chain Main Chain Hydrogen Bond Interaction\nIst Postions are Donor and Second Column are Acceptor\n")
gly_m = [[],[]]
ala_m = [[],[]]
val_m = [[],[]]
leu_m = [[],[]]
ile_m = [[],[]]
met_m = [[],[]]
phe_m =[[],[]]
trp_m =[[],[]]
pro_m = [[],[]]
ser_m = [[],[]]
thr_m = [[],[]]
cys_m = [[],[]]
tyr_m = [[],[]]
asn_m = [[],[]]
gln_m = [[],[]]
asp_m = [[],[]]
glu_m = [[],[]]
lys_m = [[],[]]
arg_m = [[],[]]
his_m = [[],[]]

gly_s = [[],[]]
ala_s = [[],[]]
val_s = [[],[]]
leu_s = [[],[]]
ile_s = [[],[]]
met_s = [[],[]]
phe_s =[[],[]]
trp_s =[[],[]]
pro_s = [[],[]]
ser_s = [[],[]]
thr_s = [[],[]]
cys_s = [[],[]]
tyr_s = [[],[]]
asn_s = [[],[]]
gln_s = [[],[]]
asp_s = [[],[]]
glu_s = [[],[]]
lys_s = [[],[]]
arg_s = [[],[]]
his_s = [[],[]]


for i in range(len(sample)):
	if (sample[i][residue] == 'GLY'):
		append_function(gly_m,i)
	if (sample[i][residue] == 'ALA'):
		append_function(ala_m,i)
	if (sample[i][residue] == 'VAL'):
		append_function(val_m,i)
	if (sample[i][residue] == 'LEU'):
		append_function(leu_m,i)	
	if (sample[i][residue] == 'ILE'):
		append_function(ile_m,i)
	if (sample[i][residue] == 'MET'):
		append_function(met_m,i)
		if(sample[i][name] == 'SD'):
			append_in_both_list(met_s,i)
	if (sample[i][residue] == 'PHE'):
		append_function(phe_m,i)
	if (sample[i][residue] == 'TRP'):
		append_function(trp_m,i)
		if(sample[i][name] == 'NE1'):
			trp_s[0].append(i)
	if (sample[i][residue] == 'PRO'):
		append_function(pro_m,i)
	if (sample[i][residue] == 'SER'):
		append_function(ser_m,i)
		if(sample[i][name] == 'OG' or sample[i][name] == 'OXT'):
			append_in_both_list(ser_s,i)
	if (sample[i][residue] == 'THR'):
		append_function(thr_m,i)
		if(sample[i][name] == 'OG1' or sample[i][name] == 'OXT'):
			append_in_both_list(thr_s,i)
	if (sample[i][residue] == 'CYS'):
		append_function(cys_m,i)
		#if(sample[i][name] == 'SG'):
		#	append_function(cys_s,i)		
	if (sample[i][residue] == 'TYR'):
		append_function(tyr_m,i)
		if(sample[i][name] == 'OH' or sample[i][name] == 'OXT'):
			append_in_both_list(tyr_s,i)
	if (sample[i][residue] == 'ASN'):
		append_function(asn_m,i)
		if(sample[i][name] == 'ND2' or sample[i][name] == 'OD1' or sample[i][name] == 'OXT'):
			append_in_both_list(asn_s,i)
	if (sample[i][residue] == 'GLN'):
		append_function(gln_m,i)
		if(sample[i][name] == 'NE2' or sample[i][name] == 'OE1' or sample[i][name] == 'OXT'):
			append_in_both_list(gln_s,i)
	if (sample[i][residue] == 'ASP'):
		append_function(asp_m,i)
		if(sample[i][name] == 'OD1' or sample[i][name] == 'OD2' or sample[i][name] == 'OXT'):
			append_in_both_list(asp_s,i)
	if (sample[i][residue] == 'GLU'):
		append_function(glu_m,i)
		if(sample[i][name] == 'OE1' or sample[i][name] == 'OE2' or sample[i][name] == 'OXT'):
			append_in_both_list(glu_s,i)
	if (sample[i][residue] == 'LYS'):
		append_function(lys_m,i)
		if(sample[i][name] == 'NZ'):
			lys_s[0].append(i)
	if (sample[i][residue] == 'ARG'):
		append_function(arg_m,i)
		if(sample[i][name] == 'NE' or sample[i][name] == 'NH1' or sample[i][name] == 'NH2'):
			arg_s[0].append(i)	
	if (sample[i][residue] == 'HIS'):
		append_function(his_m,i)
		if(sample[i][name] == 'ND1' or sample[i][name] == 'NE2'):
			append_in_both_list(his_s,i)
result = [gly_m,ala_m,val_m,leu_m,ile_m,met_m,phe_m,trp_m,pro_m,ser_m,thr_m,cys_m,tyr_m,asn_m,gln_m,asp_m,glu_m,lys_m,arg_m,his_m]

#print_output_hydrogen_chain(result)
interaction_number =  print_interaction_output_hydrogen_chain(result)
#print("Main chain Main chain Hydrogen bond:  " + str(interaction_number/(len(sample)-1)*100)+" %")

final_output = final_output+str(interaction_number/(len(sample)-1)*100)+';'

# main chain side chain
#print("\nSide Chain Main Chain Hydrogen Bond Interaction\nIst Postions are Donor and Second Column are Acceptor\n")


#TO ask donor-acceptor in arg, his, trp
# OXT 
# sulphur distance ????

result_side=[]
result_side = [gly_s,ala_s,val_s,leu_s,ile_s,met_s,phe_s,trp_s,pro_s,ser_s,thr_s,cys_s,tyr_s,asn_s,gln_s,asp_s,glu_s,lys_s,arg_s,his_s]

output =[]	
for a in range(0,2):
	if(a==0):
		b= result
		c= result_side
	if(a==1):
		b= result_side
		c= result
	for i in range(len(b)):
		for j in range(0,2):
			for k in range(len(b[i][j])):
				t= b[i][j][k]
				for l in range(len(c)):
					for m in range(0,2):
						for n in range(len(c[l][m])):
							if(j==m):
								continue
							if(i==l):
								continue
							else:
								s = c[l][m][n]
							distance = distance_calculation(t,s)
							if(distance <= 12.25 and distance >=0.0):
								append_result_in_output_Hydrogen(output,t,s,distance)
				
#output_in_sorted_order_Hydrogen(output)
interaction_number = 	output_interaction_in_sorted_order_Hydrogen(output)	

#print("Main chain Side chain Hydrogen bond:  " + str(interaction_number/(len(sample)-1)*100)+" %")

final_output = final_output+str(interaction_number/(len(sample)-1)*100)+';'


#side chain side chain
#print("\nSide Chain Side Chain Hydrogen Bond Interaction\nIst Postions are Donor and Second Column are Acceptor\n")
#print_output_hydrogen_chain(result_side)
interaction_number = 	print_interaction_output_hydrogen_chain(result_side)	

#print("Side chain Side chain Hydrogen bond:  " + str(interaction_number/(len(sample)-1)*100)+" %")		

final_output = final_output+str(interaction_number/(len(sample)-1)*100)+';'
		
#Ionic Interaction
#print('\n\n\nFollowing atoms of amino acids have ionic interaction \nSerial NO.\tName of Amino Acid\tATOM Name\n1)\t\tARGININE\t\t\tO,N,NE,NH1,NH2\n2)\t\tLYSINE\t\t\tO,N,NZ\n3)\t\tHISTIDINE\t\t\tO,N,ND1,NE2\n4)\t\tASPARTIC ACID\t\tO,OD1,OD2,N\n5)\t\tGLUTAMIC ACID\t\tO,OE1,OE2,N\n\n')
arg = [[],[],[],[],[]]
lys = [[],[],[]]
his  = [[],[],[],[]]
asp = [[],[],[],[]]
glu = [[],[],[],[]]
met =[]
cys =[]
alt_location = sample[0].index('ALT_LOCATION')
for i in range(len(sample)):
	if (sample[i][residue] == 'ARG'):
		if(sample[i][name] == 'O'):
			arg[0].append(i)
		if(sample[i][name] == 'N'):
			arg[1].append(i)
		if(sample[i][name] == 'NE'):
			arg[2].append(i)
		if(sample[i][name] == 'NH1'):
			arg[3].append(i)
		if(sample[i][name] == 'NH2'):
			arg[4].append(i)
	if(sample[i][residue] == 'LYS'):
		if(sample[i][name] == 'O'):
			lys[0].append(i)
		if(sample[i][name] == 'N'):
			lys[1].append(i)
		if(sample[i][name] == 'NZ'):
			lys[2].append(i)
	if(sample[i][residue] == 'HIS'):
		if(sample[i][name] == 'O'):
			his[0].append(i)
		if(sample[i][name] == 'N'):
			his[1].append(i)
		if(sample[i][name] == 'ND1'):
			his[2].append(i)
		if(sample[i][name] == 'NE2'):
			his[3].append(i)
	if(sample[i][residue] == 'ASP'):
		if(sample[i][name] == 'O'  and sample[i+3][name] != 'OD1' and sample[i+2][alt_location]==''):
			asp[0].append(i)
			asp[1].append(i)
			asp[2].append(i)
		elif(sample[i][name] == 'O' and sample[i][alt_location]=='' and(sample[i+2][alt_location]=='A' or sample[i+2][alt_location]=='B')):
			asp[0].append(i)
			asp[0].append(i)		
		elif(sample[i][name] == 'O' and (sample[i][alt_location]=='A' or sample[i][alt_location]=='B') and sample[i+4][name] != 'CG'):
			asp[0].append(i)
			asp[1].append(i)
			asp[2].append(i)
		elif(sample[i][name] == 'O'):
			asp[0].append(i)
		if(sample[i][name] == 'OD1'):
			asp[1].append(i)
		if(sample[i][name] == 'OD2'):
			asp[2].append(i)
		if(sample[i][name] == 'N' and sample[i][alt_location]=='' and (sample[i+5][alt_location]=='A' or sample[i+5][alt_location]=='B')):
			asp[3].append(i)		
			asp[3].append(i)		
		elif(sample[i][name] == 'N'):	
			asp[3].append(i)
	if(sample[i][residue] == 'GLU'):
		if(sample[i][name] == 'O' and sample[i+4][name] != 'OE1' and sample[i+1][alt_location]==''):
			glu[0].append(i)
			glu[1].append(i)
			glu[2].append(i)
		elif(sample[i][name] == 'O' and sample[i][alt_location]=='' and(sample[i+1][alt_location]=='A' or sample[i+1][alt_location]=='B')):
			glu[0].append(i)
			glu[0].append(i)
		elif(sample[i][name] == 'O' and (sample[i][alt_location]=='A' or sample[i][alt_location]=='B') and sample[i+4][name] != 'CG'):
			glu[0].append(i)
			glu[1].append(i)
			glu[2].append(i)
		elif(sample[i][name] == 'O'):
			glu[0].append(i)
		if(sample[i][name] == 'OE1'):
			glu[1].append(i)
		if(sample[i][name] == 'OE2'):
			glu[2].append(i)
		if(sample[i][name] == 'N' and sample[i][alt_location]=='' and (sample[i+4][alt_location]=='A' or sample[i+4][alt_location]=='B')):
			glu[3].append(i)		
			glu[3].append(i)		
		elif(sample[i][name] == 'N'):
			glu[3].append(i)	
	#for aromatic sulphur interaction
	if (sample[i][residue] == 'MET'):
		if(sample[i][name] == 'SD'):
			met.append(i)

			
result = []
result.append(arg)
result.append(lys)
result.append(his)
result.append(asp)
result.append(glu)
output = []

for i in range(len(result)):
	for j in range(len(result[i])):
		for k in range(len(result[i][j])):
			t= result[i][j][k]
			for l in range(len(result)):
				for m in range(len(result[l])):
					for n in range(len(result[l][m])):
						if(i > l):
							continue
						elif(i==l):
							continue
						elif(i!=l or j!= m or k!=n):
							if(i==0 or i==1 or i==2):
								if(j==0):
									continue
								if(l==0 or l==1 or l==2):
									continue
								else:
									if(m == 3):
										continue
									else:
										s = result[l][m][n]
							distance = distance_calculation(t,s)
							"""w = '21'
							c = '66'
							if((sample[t][residue_sequence_no] ==w and sample[s][residue_sequence_no]==c) or (sample[t][residue_sequence_no]==c and sample[s][residue_sequence_no]==w)):
								print(str(math.sqrt(distance))+'\t'+str(sample[t][residue]+'\t'+str(sample[s][residue]))+'\t'+str(sample[t][residue_sequence_no])+'\t'+str(sample[s][residue_sequence_no])+'\t'+sample[t][name]+'\t'+sample[s][name])"""
							if (distance <= 36.0 and t < s and sample[t][residue] != sample[s][residue]):
								append_result_in_output(output,t,s,distance)
							elif(distance <=36.0 and t >= s and sample[t][residue] != sample[s][residue]):
								append_result_in_output(output,s,t,distance)

#output_in_sorted_order(output)	
interaction_number = 	output_interaction_in_sorted_order(output)	

#print("Ionic Interactions:  " + str(interaction_number/(len(sample)-1)*100)+" %")

final_output = final_output+str(interaction_number/(len(sample)-1)*100)+';'


"""def trp_centroid(t1,t2,t3,t11,t12,t13,centroid_l,area_l):
	a = [float(sample[t1][x_coordi]),float(sample[t2][x_coordi]),float(sample[t3][x_coordi]),float(sample[t1][y_coordi]),float(sample[t2][y_coordi]),float(sample[t3][y_coordi]),float(sample[t1][z_coordi]),float(sample[t2][z_coordi]),float(sample[t3][z_coordi])]
	b = [float(sample[t11][x_coordi]),float(sample[t12][x_coordi]),float(sample[t13][x_coordi]),float(sample[t11][y_coordi]),float(sample[t12][y_coordi]),float(sample[t13][y_coordi]),float(sample[t11][z_coordi]),float(sample[t12][z_coordi]),float(sample[t13][z_coordi])]
	ax = [a[0],a[1],a[2]]
	ay = [a[3],a[4],a[5]]
	az = [a[6],a[7],a[8]]
	bx = [b[0],b[1],b[2]]
	by = [b[3],b[4],b[5]]
	bz = [b[6],b[7],b[8]]
	centroid = [(ax[0]+ax[1]+ax[2])/3,(ay[0]+ay[1]+ay[2])/3,(az[0]+az[1]+az[2])/3]
	e1 = [ax[1]-ax[0],ay[1]-ay[0],az[1]-az[0]]
	e2 = [ax[2]-ax[0],ay[2]-ay[0],az[2]-az[0]]
	area1 = [e1[1]*e2[2]- e1[2]*e2[1], e1[2]*e2[0] - e1[0]*e2[2], e1[0]*e2[1] - e1[1]*e2[0]]
	area = 0.5 * math.sqrt((area1[0] * area1[0] + area1[1] * area1[1] + area1[2] * area1[2] ))
	f1 = [bx[1]-bx[0],by[1]-by[0],bz[1]-bz[0]]
	f2 = [bx[2]-bx[0],by[2]-by[0],bz[2]-bz[0]]
	area2 = [f1[1]*f2[2]- f1[2]*f2[1], f1[2]*f2[0] - f1[0]*f2[2], f1[0]*f2[1] - f1[1]*f2[0]]
	check1 = area1[0] * area2[0] + area1[1] * area2[1] + area1[2] * area2[2]  
	if(check1 >= 0):
		centroid_l.append(centroid)
		area_l.append(area)
		return centroid_l, area_l
	else:
		centroid_l.append(centroid)
		area_l.append(area * (-1.0))
		return centroid_l, area_l
"""

#aromatic aromatic interaction

#print('\n\n\n\n\n\nFollowing atoms of amino acids have aromatic aromatic interaction \nSerial NO.\tName of Amino Acid\tATOM Name\n1)\t\tPHENYLALANINE\t\tCG,CD1,CD2,CE1,CE2,CZ\n2)\t\tTRYOSINE\t\t\tCG,CD1,CD2,CE1,CE2,CZ\n3)\t\tTRYPTOPHAN\t\t\tCG,CD1,CD2,NE1,CE2,CE3,CZ2,CZ3,CH2\n')
output = []
result = []
phe = []
trp =[]
tyr  = []
#his = []
for i in range(len(sample)):
	if (sample[i][residue] == 'PHE' ):
		if(sample[i][name] == 'CG'):
			x_centroid = y_centroid = z_centroid = 0
			a = []
			x_centroid = (float(sample[i][x_coordi]) + float(sample[i+1][x_coordi] )+float( sample[i+2][x_coordi] )+float( sample[i+3][x_coordi] )+ float(sample[i+4][x_coordi]) + float(sample[i+5][x_coordi] ))/6
			y_centroid = (float(sample[i][y_coordi]) + float(sample[i+1][y_coordi]) + float(sample[i+2][y_coordi]) + float(sample[i+3][y_coordi]) + float(sample[i+4][y_coordi]) + float(sample[i+5][y_coordi]) )/6
			z_centroid = (float(sample[i][z_coordi]) + float(sample[i+1][z_coordi]) + float(sample[i+2][z_coordi]) + float(sample[i+3][z_coordi]) + float(sample[i+4][z_coordi]) + float(sample[i+5][z_coordi]) )/6
			a.append(i)
			a.append(x_centroid)
			a.append(y_centroid)
			a.append(z_centroid)
			phe.append(a)
	"""if (sample[i][residue] == 'HIS' ):
		if(sample[i][name] == 'CG'):
			x_centroid = y_centroid = z_centroid = 0
			a = []
			x_centroid = (float(sample[i][x_coordi]) + float(sample[i+1][x_coordi] )+float( sample[i+2][x_coordi] )+float( sample[i+3][x_coordi] )+ float(sample[i+4][x_coordi]))/5
			y_centroid = (float(sample[i][y_coordi]) + float(sample[i+1][y_coordi]) + float(sample[i+2][y_coordi]) + float(sample[i+3][y_coordi]) + float(sample[i+4][y_coordi]))/5
			z_centroid = (float(sample[i][z_coordi]) + float(sample[i+1][z_coordi]) + float(sample[i+2][z_coordi]) + float(sample[i+3][z_coordi]) + float(sample[i+4][z_coordi]))/5
			a.append(i)
			a.append(x_centroid)
			a.append(y_centroid)
			a.append(z_centroid)
			his.append(a)"""
	if(sample[i][residue] == 'TYR'):
			if(sample[i][name] == 'CG'):
				x_centroid = 0
				y_centroid = 0
				z_centroid = 0
				a = []
				x_centroid = (float(sample[i][x_coordi]) + float(sample[i+1][x_coordi]) + float(sample[i+2][x_coordi]) + float(sample[i+3][x_coordi]) + float(sample[i+4][x_coordi]) + float(sample[i+5][x_coordi]) )/6
				y_centroid = (float(sample[i][y_coordi]) + float(sample[i+1][y_coordi]) + float(sample[i+2][y_coordi]) + float(sample[i+3][y_coordi]) + float(sample[i+4][y_coordi]) + float(sample[i+5][y_coordi]) )/6
				z_centroid = (float(sample[i][z_coordi]) + float(sample[i+1][z_coordi]) + float(sample[i+2][z_coordi]) + float(sample[i+3][z_coordi]) + float(sample[i+4][z_coordi]) + float(sample[i+5][z_coordi]) )/6
				a.append(i)
				a.append(x_centroid)
				a.append(y_centroid)
				a.append(z_centroid)
				tyr.append(a)
	if(sample[i][residue] == 'TRP' ):
		if(sample[i][name] == 'CG'):
			x_centroid = 0
			y_centroid = 0
			z_centroid = 0
			a = []
			centroid_list = []
			area_list = []
			
			"""trp_centroid(i,i+1,i+3,i,i+1,i+3,centroid_list,area_list)
			trp_centroid(i,i+3,i+4,i,i+1,i+3,centroid_list,area_list)
			trp_centroid(i,i+4,i+6,i,i+1,i+3,centroid_list,area_list)
			trp_centroid(i,i+6,i+8,i,i+1,i+3,centroid_list,area_list)
			trp_centroid(i,i+8,i+7,i,i+1,i+3,centroid_list,area_list)
			trp_centroid(i,i+7,i+5,i,i+1,i+3,centroid_list,area_list)
			trp_centroid(i,i+5,i+2,i,i+1,i+3,centroid_list,area_list)
			total_area = 0.0
			total_centroid = [0.0,0.0,0.0]
			for kk in range(len(area_list)):
				total_area  = total_area + area_list[kk]
				centroid_list[kk][0] = centroid_list[kk][0] * area_list[kk]
				centroid_list[kk][1] = centroid_list[kk][1] * area_list[kk]
				centroid_list[kk][2] = centroid_list[kk][2] * area_list[kk]
				total_centroid[0] = total_centroid[0] + centroid_list[kk][0]
				total_centroid[1] = total_centroid[1] + centroid_list[kk][1]
				total_centroid[2] = total_centroid[2] + centroid_list[kk][2]
			print("\n\ncentroid after area normalization  ",centroid_list)
			print("\n\nsum of centroids  ",total_centroid)
			print("\n\ntotal area  ",total_area)
			print("\n\nfinal centroid  ",total_centroid[0]/total_area,total_centroid[1]/total_area,total_centroid[2]/total_area)
			a.append(i)
			a.append(total_centroid[0]/total_area)
			a.append(total_centroid[1]/total_area)
			a.append(total_centroid[2]/total_area)
			trp.append(a)"""

			x_c_p = (float(sample[i+2][x_coordi]) + float(sample[i+4][x_coordi] )+float( sample[i+5][x_coordi] )+float( sample[i+6][x_coordi] )+ float(sample[i+7][x_coordi])+ float(sample[i+8][x_coordi]))/6
			y_c_p = (float(sample[i+2][y_coordi]) + float(sample[i+4][y_coordi]) + float(sample[i+5][y_coordi]) + float(sample[i+6][y_coordi]) + float(sample[i+7][y_coordi])+ float(sample[i+8][y_coordi]))/6
			z_c_p = (float(sample[i+2][z_coordi]) + float(sample[i+4][z_coordi]) + float(sample[i+5][z_coordi]) + float(sample[i+6][z_coordi]) + float(sample[i+7][z_coordi])+ float(sample[i+8][z_coordi]))/6
			a= []
			a.append(i)
			a.append(x_c_p)
			a.append(y_c_p)
			a.append(z_c_p)
			trp.append(a)
			
result.append(phe)
result.append(tyr)
result.append(trp)


for i in range(0,len(result)):
	for j in range(0,len(result[i])):
		t = result[i][j][0]
		for k in range(0,len(result)):
			for l in range(0,len(result[k])):
				if(i==k and j==l):
					continue
				elif(i > k):
					continue
				elif(i ==k and j > l):
					continue
				else:
					s = result[k][l][0]
					distance = (result[i][j][1] - result[k][l][1])*(result[i][j][1] - result[k][l][1])+(result[i][j][2] - result[k][l][2])*(result[i][j][2] - result[k][l][2])+(result[i][j][3] - result[k][l][3])*(result[i][j][3] - result[k][l][3])
					if ( distance >= 20.25 and t < s and distance <=49.0):
						append_result_in_output(output,t,s,distance)
					elif( distance >= 20.25 and t >= s and distance <=49.0):
						append_result_in_output(output,s,t,distance)

#output_in_sorted_order(output)	
interaction_number = 	output_interaction_in_sorted_order(output)	

#print("Aromatic Aromatic Interactions:  " + str(interaction_number/(len(sample)-1)*100)+" %")

final_output = final_output+str(interaction_number/(len(sample)-1)*100)+';'


#aromatic sulphur interaction
#print('\n\n\n\n\n\nFollowing atoms of amino acids have aromatic sulphur interaction \nSerial NO.\tName of Amino Acid\tATOM Name\n1)\t\tPHENYLALANINE\t\tCG,CD1,CD2,CE1,CE2,CZ\n2)\t\tTRYOSINE\t\t\tCG,CD1,CD2,CE1,CE2,CZ\n3)\t\tTRYPTOPHAN\t\t\tCG,CD1,CD2,NE1,CE2,CE3,CZ2,CZ3,CH2\n4)\t\tMETHIONINE\t\t\tSD\n3)\t\tCYSTEINE\t\t\tSG\n')
sul_out = []
output= []

sul_out.append(met)
sul_out.append(cys)


for i in range(0,len(result)):
	for j in range(0,len(result[i])):
		t = result[i][j][0]
		for k in range(0,len(sul_out)):
			for l in range(0,len(sul_out[k])):
				s = sul_out[k][l]
				distance = (float(sample[s][x_coordi]) - result[i][j][1])* (float(sample[s][x_coordi]) - result[i][j][1]) + (float(sample[s][y_coordi]) - result[i][j][2]) * (float(sample[s][y_coordi]) -  result[i][j][2]) + (float(sample[s][z_coordi]) -  result[i][j][3]) * (float(sample[s][z_coordi]) -  result[i][j][3])
				if (distance <= 28.09):
					append_result_in_output(output,t,s,distance)
#output_in_sorted_order(output)	

interaction_number = 	output_interaction_in_sorted_order(output)	

#print("Aromatic Sulphur Interactions:  " + str(interaction_number/(len(sample)-1)*100)+" %")

final_output = final_output+str(interaction_number/(len(sample)-1)*100)+';'


#cation pi interaction
#print('\n\n\n\n\n\nFollowing atoms of amino acids have Cation Pi interaction \nSerial NO.\tName of Amino Acid\tATOM Name\n1)\t\tPHENYLALANINE\t\tCG,CD1,CD2,CE1,CE2,CZ\n2)\t\tTRYOSINE\t\t\tCG,CD1,CD2,CE1,CE2,CZ\n3)\t\tTRYPTOPHAN\t\t\tCG,CD1,CD2,NE1,CE2,CE3,CZ2,CZ3,CH2\n4)\t\tMETHIONINE\t\t\tCD\n3)\t\tCYSTEINE\t\t\tSG\n')
output = []
cation = []
cation.append([lys[1],lys[2]])
cation.append([arg[1],arg[2],arg[3],arg[4]])
for i in range(0,len(result)):
	for j in range(0,len(result[i])):
		t = result[i][j][0]		
		for k in range(0,len(cation)):
			for l in range(0,len(cation[k])):
				for m in range(0,len(cation[k][l])):
					s = cation[k][l][m]
					distance = (float(sample[s][x_coordi]) - result[i][j][1])* (float(sample[s][x_coordi]) - result[i][j][1]) + (float(sample[s][y_coordi]) - result[i][j][2]) * (float(sample[s][y_coordi]) -  result[i][j][2]) + (float(sample[s][z_coordi]) -  result[i][j][3]) * (float(sample[s][z_coordi]) -  result[i][j][3])
					if (distance <= 36.00):
						append_result_in_output(output,t,s,distance)
#output_in_sorted_order(output)	

interaction_number = 	output_interaction_in_sorted_order(output)	

#print("Cation Pi Interactions:  " + str(interaction_number/(len(sample)-1)*100)+" %")

final_output = final_output+str(interaction_number/(len(sample)-1)*100)+';'


#salt bridge
#sub part of ionic ionic interaction
arg = []
lys = []
his  = []
asp = []
glu = [] 

for i in range(len(sample)):
	j=[]
	if (sample[i][residue] == 'ARG'):
		if(sample[i][name] == 'NH1' or sample[i][name] == 'NH2'):				
			arg.append(i)
	if(sample[i][residue] == 'LYS'):
		if(sample[i][name] == 'NZ'):
			lys.append(i)
	if(sample[i][residue] == 'HIS'):
		if(sample[i][name] == 'ND1' or sample[i][name] == 'NE2'):			
			his.append(i)
	if(sample[i][residue] == 'ASP'):
		if(sample[i][name] == 'OD1' or sample[i][name] == 'OD2'):	
			asp.append(i)
	if(sample[i][residue] == 'GLU'):
		if(sample[i][name] == 'OE1' or sample[i][name] == 'OE2'):	
			glu.append(i)

			
result_acid = []
result_basic = []
result_basic.append(arg)
result_basic.append(lys)
result_basic.append(his)
result_acid.append(asp)
result_acid.append(glu)
output = []

for i in range(len(result_acid)):
	for j in range(len(result_acid[i])):
			t= result_acid[i][j]
			for l in range(len(result_basic)):
				for m in range(len(result_basic[l])):
							s = result_basic[l][m]
							distance = distance_calculation(t,s)
							if (distance <= 16.0 and t < s and sample[t][residue] != sample[s][residue]):
								append_result_in_output(output,t,s,distance)
							elif(distance <= 16.0 and t >= s and sample[t][residue] != sample[s][residue]):
								append_result_in_output(output,s,t,distance)


#output_in_sorted_order(output)	
interaction_number = 	len(output)	

#print("Ionic Interactions:  " + str(interaction_number/(len(sample)-1)*100)+" %")

final_output = final_output+str(interaction_number/(len(sample)-1)*100)






print(atom_count)
print(len(set(residue_count)))
print(final_output)
