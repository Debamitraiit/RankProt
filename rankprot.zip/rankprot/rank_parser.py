#! /user/bin/env python3
import sys
import math

#taking input from a file
file= open(sys.argv[1])
for i in file.readlines():
	list_1 = i.replace("\n","").split(';')

file= open(sys.argv[2])
for i in file.readlines():
	list_2 = i.replace("\n","").split(';')


if(len(list_1) < len(list_2)):
	for i in range(0, max(len(list_1),len(list_2)) - min(len(list_1),len(list_2)) ):
		list_1.append('0.0')


if(len(list_1) > len(list_2)):
	for i in range(0, max(len(list_1),len(list_2)) - min(len(list_1),len(list_2)) ):
		list_2.append('0.0')


list_3 = []
for i in range(0,len(list_1)):
	list_3.append(float(list_1[i])+float(list_2[i]))
	if(list_3[i] != 0.0):
		list_1[i] = float(list_1[i])/list_3[i]
		list_2[i] = float(list_2[i])/list_3[i]

file=open(sys.argv[3])
eigen = []
for i in file.readlines():
	eigen.append(i.replace("\n",""))


rank1 = 0.0
rank2 = 0.0

for i in range(0,len(list_1)):
	rank1 = rank1 + float(list_1[i])*float(eigen[i])
	rank2 = rank2 + float(list_2[i])*float(eigen[i])


print("FILE NAME\tRANK")
print(sys.argv[4] + '\t' + str(rank1))

print(sys.argv[5] + '\t' + str(rank2))


