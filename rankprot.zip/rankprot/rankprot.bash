#!/bin/bash

# give the path of your promotif3
export motifdir='/home/research/promotif3_v1'
alias promotif="$motifdir'/promotif.scr'"
alias promotif_multi="$motifdir'/promotif_multi.scr'"
alias promotif_nmr="$motifdir'/promotif_nmr.scr'"


  
FILE=$1
echo $FILE

# give the path of your promotif3
/home/research/promotif3_v1/promotif.scr $FILE
FILE=${FILE%.*}


FILE_BT=$FILE.bturns
N_BT=`wc -l < $FILE_BT`
declare -i N_BT

if [ $N_BT -gt 0 ]
then
N_BT=$N_BT-2
fi

FILE_GT=$FILE.gturns
N_GT=`wc -l < $FILE_GT`
declare -i N_GT

if [ $N_GT -gt 0 ]
then
N_GT=$N_GT-2
fi

N_IT=`grep "INVERSE" $FILE_GT | wc -l`
declare -i N_IT
N_IT=$N_IT

echo "python script starts"
echo "interaction calculation starts"
python3 protein.py $FILE.pdb > protein.txt
INTER=`cat protein.txt | tail -1`
RESIDUE=`cat protein.txt | head -2 | tail -1`
ATOM=`cat protein.txt | head -1 | tail -2` 
echo "interaction calculation ends"

echo $INTER
echo $RESIDUE
echo $ATOM
echo "vadar calculation starts"

# give the path of your vadar
/home/research/bin/vadar -f $1 -o 1


VADAR=`python3 parsing_vadar.py 1.stats $ATOM`
PROMOTIF=`python3 promotif_parsing.py $N_GT $N_IT $N_BT $RESIDUE`
echo "vadar calculation ends"

echo "$INTER;$PROMOTIF;$VADAR" > ./rank_file/1.txt





FILE=$2
echo $FILE


# give the path of your promotif3
/home/research/promotif3_v1/promotif.scr $FILE
FILE=${FILE%.*}


FILE_BT=$FILE.bturns
N_BT=`wc -l < $FILE_BT`
declare -i N_BT

if [ $N_BT -gt 0 ]
then
N_BT=$N_BT-2
fi

FILE_GT=$FILE.gturns
N_GT=`wc -l < $FILE_GT`
declare -i N_GT

if [ $N_GT -gt 0 ]
then
N_GT=$N_GT-2
fi

N_IT=`grep "INVERSE" $FILE_GT | wc -l`
declare -i N_IT
N_IT=$N_IT

echo "python script starts"
echo "interaction calculation starts"
python3 protein.py $FILE.pdb > protein.txt
INTER=`cat protein.txt | tail -1`
RESIDUE=`cat protein.txt | head -2 | tail -1`
ATOM=`cat protein.txt | head -1 | tail -2` 
echo "interaction calculation ends"

echo $INTER
echo $RESIDUE
echo $ATOM
echo "vadar calculation starts"


# give the path of your vadar
/home/research/bin/vadar -f $2 -o 2

VADAR=`python3 parsing_vadar.py 2.stats $ATOM`
PROMOTIF=`python3 promotif_parsing.py $N_GT $N_IT $N_BT $RESIDUE`
echo "vadar calculation ends"


echo "$INTER;$PROMOTIF;$VADAR" > ./rank_file/2.txt


echo -e "\n\nRanking Starts"
echo  -e "\n\n\tPress 1 for checking thermostability\n"
RANK=``
read STABILITY


if [ $STABILITY -eq 1 ]
then
RANK=`python rank_parser.py ./rank_file/1.txt ./rank_file/2.txt ./rank_file/eigen.txt $1 $2`
fi


echo "Ranking ends"
echo -e "\n\n$RANK\n\n"
echo "$RANK" > ./rank_file/rank.txt





